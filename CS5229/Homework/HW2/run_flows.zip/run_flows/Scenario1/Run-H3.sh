#!/bin/bash
iperf3 -s