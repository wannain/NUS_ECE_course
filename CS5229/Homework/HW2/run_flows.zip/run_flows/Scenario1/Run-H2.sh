#!/bin/bash
echo "No flow from H2"